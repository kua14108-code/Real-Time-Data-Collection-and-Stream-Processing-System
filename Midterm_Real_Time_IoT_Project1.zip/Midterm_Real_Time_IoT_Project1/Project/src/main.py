"""Entry point for the real-time IoT stream processing demonstration."""
from __future__ import annotations
import argparse
import time
from pathlib import Path
import pandas as pd

from generator import generate_stream, save_input_csv
from processor import StreamProcessor
from visualization import create_visualization

def run(n_records: int, delay: float, output_dir: str, seed: int = 42) -> None:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    input_path = out / "input_stream.csv"
    processed_path = out / "processed_results.csv"
    plot_path = out / "realtime_visualization.png"

    # Reproducible input source is stored before the live-style pass.
    save_input_csv(str(input_path), n_records=n_records, seed=seed)

    processor = StreamProcessor(window=10)
    results = []

    print("\nStarting incremental stream processing...")
    for record in generate_stream(n_records=n_records, seed=seed):
        result = processor.process_record(record)
        results.append(result)
        status = "ANOMALY" if result["anomaly"] else "OK"
        print(
            f'{result["timestamp"]} | T={result["temperature_c"]:5.2f}°C | '
            f'H={result["humidity_pct"]:5.2f}% | '
            f'MA={result["temperature_moving_avg"]:5.2f} | '
            f'Events={result["event_count"]:2d} | {status}'
        )
        if delay > 0:
            time.sleep(delay)

    df = pd.DataFrame(results)
    df.to_csv(processed_path, index=False)
    create_visualization(str(processed_path), str(plot_path))

    print("\nCompleted.")
    print(f"Input:     {input_path}")
    print(f"Processed: {processed_path}")
    print(f"Plot:      {plot_path}")
    print("\nLast 10 processed records:")
    print(df.tail(10)[[
        "timestamp", "temperature_c", "humidity_pct",
        "temperature_moving_avg", "rolling_temperature_std",
        "event_count", "anomaly", "event_type"
    ]].to_string(index=False))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--records", type=int, default=120)
    parser.add_argument("--delay", type=float, default=0.0,
                        help="Seconds between records; use 0 for fast demonstration.")
    parser.add_argument("--output-dir", default="../results")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    run(args.records, args.delay, args.output_dir, args.seed)
