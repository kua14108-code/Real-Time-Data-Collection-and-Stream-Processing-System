"""Reproducible timestamped IoT stream generator."""
from __future__ import annotations
from datetime import datetime, timedelta
import random
from typing import Dict, Iterator, Optional

def generate_stream(
    n_records: int = 120,
    start_time: Optional[datetime] = None,
    interval_seconds: int = 1,
    seed: int = 42,
) -> Iterator[Dict]:
    """Yield one sensor record at a time, simulating incremental acquisition."""
    rng = random.Random(seed)
    start_time = start_time or datetime(2026, 10, 1, 12, 0, 0)

    for i in range(n_records):
        ts = start_time + timedelta(seconds=i * interval_seconds)
        # Smooth baseline + small noise
        temperature = 22.0 + 1.8 * __import__("math").sin(i / 18) + rng.gauss(0, 0.35)
        humidity = 55.0 + 6.0 * __import__("math").sin(i / 25 + 0.5) + rng.gauss(0, 1.5)

        # Deterministic injected anomalies for demonstration.
        if 35 <= i <= 39:
            temperature += 12.0
        if 78 <= i <= 81:
            humidity += 34.0

        yield {
            "timestamp": ts.isoformat(),
            "sensor_id": "SENSOR_01",
            "temperature_c": round(temperature, 3),
            "humidity_pct": round(humidity, 3),
        }

def save_input_csv(path: str, n_records: int = 120, seed: int = 42) -> None:
    import pandas as pd
    records = list(generate_stream(n_records=n_records, seed=seed))
    pd.DataFrame(records).to_csv(path, index=False)
