"""Incremental Pandas/NumPy stream processor and anomaly detector."""
from __future__ import annotations
from collections import deque
from typing import Dict, List
import numpy as np
import pandas as pd

class StreamProcessor:
    def __init__(self, window: int = 10, temp_low: float = 15.0,
                 temp_high: float = 30.0, humidity_high: float = 85.0):
        self.window = window
        self.temp_low = temp_low
        self.temp_high = temp_high
        self.humidity_high = humidity_high
        self.buffer = deque(maxlen=window)
        self.event_count = 0

    def process_record(self, record: Dict) -> Dict:
        """Process exactly one incoming record and return an analysis row."""
        row = pd.DataFrame([record])
        row["timestamp"] = pd.to_datetime(row["timestamp"])
        row["temperature_c"] = pd.to_numeric(row["temperature_c"], errors="coerce")
        row["humidity_pct"] = pd.to_numeric(row["humidity_pct"], errors="coerce")
        row = row.dropna(subset=["timestamp", "temperature_c", "humidity_pct"])

        self.buffer.append(row.iloc[0].to_dict())
        window_df = pd.DataFrame(self.buffer)

        temp_values = window_df["temperature_c"].to_numpy(dtype=float)
        humidity_values = window_df["humidity_pct"].to_numpy(dtype=float)

        moving_avg = float(np.mean(temp_values))
        rolling_std = float(np.std(temp_values, ddof=0))
        temp_min = float(np.min(temp_values))
        temp_max = float(np.max(temp_values))

        temp = float(row.iloc[0]["temperature_c"])
        humidity = float(row.iloc[0]["humidity_pct"])
        flags = []
        if temp < self.temp_low or temp > self.temp_high:
            flags.append("temperature_threshold")
        if humidity > self.humidity_high:
            flags.append("humidity_threshold")

        # NumPy-based local z-score rule, enabled only after 5 observations.
        z_score = 0.0
        if len(temp_values) >= 5 and rolling_std > 0:
            prior = temp_values[:-1]
            z_score = float((temp - np.mean(prior)) / max(np.std(prior), 1e-9))
            if abs(z_score) >= 3.0:
                flags.append("temperature_zscore")

        is_anomaly = bool(flags)
        if is_anomaly:
            self.event_count += 1

        return {
            "timestamp": row.iloc[0]["timestamp"].isoformat(),
            "sensor_id": row.iloc[0]["sensor_id"],
            "temperature_c": temp,
            "humidity_pct": humidity,
            "temperature_moving_avg": moving_avg,
            "rolling_temperature_std": rolling_std,
            "window_min_temperature": temp_min,
            "window_max_temperature": temp_max,
            "event_count": self.event_count,
            "z_score": z_score,
            "anomaly": is_anomaly,
            "event_type": "|".join(flags) if flags else "",
        }
