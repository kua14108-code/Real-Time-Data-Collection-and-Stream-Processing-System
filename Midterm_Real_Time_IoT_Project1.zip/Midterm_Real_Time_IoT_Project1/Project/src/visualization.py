"""Visualization utilities for processed stream results."""
from __future__ import annotations
import pandas as pd
import matplotlib.pyplot as plt

def create_visualization(input_csv: str, output_png: str) -> None:
    df = pd.read_csv(input_csv, parse_dates=["timestamp"])
    fig, ax = plt.subplots(figsize=(10, 5.5))
    ax.plot(df["timestamp"], df["temperature_c"], label="Temperature (°C)")
    ax.plot(df["timestamp"], df["temperature_moving_avg"],
            label="10-record moving average")
    anomalies = df[df["anomaly"] == True]
    if not anomalies.empty:
        ax.scatter(anomalies["timestamp"], anomalies["temperature_c"],
                   label="Detected anomaly")
    ax.set_title("Real-Time IoT Temperature Stream")
    ax.set_xlabel("Timestamp")
    ax.set_ylabel("Temperature (°C)")
    ax.legend()
    ax.grid(True, alpha=0.25)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(output_png, dpi=160)
    plt.close(fig)
